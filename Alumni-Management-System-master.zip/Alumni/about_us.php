<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>About Us</title>
<link rel="stylesheet" href="css/about_us.css" />

<?php
include_once"setting/aboutus_navigation.php";
?>
</head>

<body>
<div id="history">
<p class="p1">Goverment Polytechnic Mumbai Alumni Management</p>
<p class="p3">The GPM Alumni Association supervises the graduate programs in GPM. 
	This includes administering the admission, appointment of Alumnis, Members reviews, 
	provision of financial assistance and assessment. </p><br />
<p class="p2">FUNCTION OF  ALUMNI  MANAGEMENT  SYSTEM (AMS)</p>
<p class="p3">The function of AMS includes the following:
<ul class="ul2">
	<li>Promoting GPM’s graduate programs</li>
	<li>Facilitate the appointment of Alumni's after graduation</li>
	<li>Oversees the provision of financial assistance</li>
	<li>Organises events for Alumnis </li>
	<li>Facilitate communication between Alumnis after graduation </li>
	<li>Coordinate the assessment for graduation purposes</li>
	<li>Organise activities to enhance graduate students research capabilities</li>
</ul>
</p>
</div>
</body>
</html>